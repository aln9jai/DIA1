import UIKit

// Aby y Alan

/*
 Aby y Alan
 MAC
 18
 */

let nombre: String = "Juan"
let ganar: Bool = true
var clases: Int = 16

var hola: String?
var altura: Float?
var años: Int?
var ios: Double?

var adios = 2
var x = 5
var y = 3
var z = 4

let info: (String, String) = (nombre: "Aby y Alan", apellido: "Soto y Ramirez")
var edades = 18
